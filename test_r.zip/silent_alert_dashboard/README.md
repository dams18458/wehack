# Silent Alert Dispatch Dashboard

A minimal, local, pitch-ready web dashboard built with Flask and vanilla HTML/JS to demonstrate a covert **"Silent Alert"** action for a hackathon demo.

Designed with a calm, dark, non-alarming aesthetic: when an alert fires, it avoids jarring sirens or generic gradient templates, presenting a clear, stealthy incident transmission monitor suitable for live pitches.

---

## Features

1. **Clean, Restrained UI**:
   - Deep obsidian dark palette (`#090b0e` / `#12151c`), crisp monospace metrics, and architectural typography.
   - Dual-state status banner: **`System Idle`** (calm monitoring) $\leftrightarrow$ **`Alert Sent`** (covert dispatch active).
   - Prominently showcases the **mock contact name**, **incident timestamp**, **confidence score meter**, and **evidence audio path reference**.
   - Chronological event log table detailing all past dispatches.
2. **Real-Time 2-Second Polling**:
   - Pure vanilla JavaScript polls `GET /api/alerts` every 2000ms.
   - Seamless DOM updates without full page reloads or layout shifts.
3. **In-Memory Storage**:
   - Zero external databases or cloud services. Everything runs locally in-memory.
4. **Rehearsal Controls**:
   - **On-Page Test Button**: "⚡ Simulate Trigger Event" allows manual rehearsal on stage without needing the real audio pipeline running.
   - **Reset to Idle Button**: Quickly clears the alert log back to idle between pitch practice rounds.

---

## Getting Started

### 1. Requirements & Setup
- Python 3.9+
- Flask (`pip install flask`)

Install dependencies:
```bash
pip install -r requirements.txt
```

### 2. Run the Dashboard
```bash
python app.py
```

By default, the dashboard starts at:
👉 **`http://127.0.0.1:5000/`**

---

## How to Send Test Triggers

You can trigger alerts through three convenient methods:

### Method A: On-Page Rehearsal Button (Recommended for Live Demo)
1. Open `http://127.0.0.1:5000/` in your browser.
2. Click the **"⚡ Simulate Trigger Event"** button at the bottom.
3. Within 2 seconds, the dashboard transitions from **`System Idle`** to **`Alert Sent`**, displaying the contact, timestamp, and confidence bar.
4. Click **"Reset to Idle"** to clear the board and re-demonstrate.

---

### Method B: Using `curl`

#### In Bash / macOS / Linux:
```bash
curl -X POST http://127.0.0.1:5000/trigger \
  -H "Content-Type: application/json" \
  -d '{
    "contact": "Sarah Chen (Emergency Contact)",
    "timestamp": "2026-09-05 10:48:15",
    "confidence": 89.4,
    "audio_path": "evidence/duress_evidence_20260905_104815.wav"
  }'
```

#### In Windows PowerShell:
```powershell
Invoke-RestMethod -Uri "http://127.0.0.1:5000/trigger" `
  -Method POST `
  -ContentType "application/json" `
  -Body (@{
    contact = "Sarah Chen (Emergency Contact)"
    timestamp = "2026-09-05 10:48:15"
    confidence = 89.4
    audio_path = "evidence/duress_evidence_20260905_104815.wav"
  } | ConvertTo-Json)
```

---

### Method C: Using the Python CLI Helper
A companion script `send_test_alert.py` is included:
```bash
python send_test_alert.py --contact "Alex Mercer (Security Proxy)" --confidence 94.2
```

---

## API Reference

### `POST /trigger`
Accepts a JSON payload recording a new duress trigger event.

**Request Body**:
```json
{
  "contact": "Sarah Chen (Emergency Contact)",
  "timestamp": "2026-09-05 10:48:15",
  "confidence": 89.4,
  "audio_path": "evidence/duress_evidence_20260905_104815.wav"
}
```

**Response (201 Created)**:
```json
{
  "status": "success",
  "message": "Alert recorded successfully",
  "alert": {
    "id": 1,
    "contact": "Sarah Chen (Emergency Contact)",
    "timestamp": "2026-09-05 10:48:15",
    "confidence": 89.4,
    "audio_path": "evidence/duress_evidence_20260905_104815.wav",
    "received_at": "2026-09-05 10:48:15"
  }
}
```

---

### `GET /api/alerts`
Returns active status and chronological alert history.

**Response (200 OK)**:
```json
{
  "status": "alert_sent",
  "count": 1,
  "latest": { ... },
  "alerts": [ ... ]
}
```

---

### `POST /reset`
Clears in-memory history, resetting the dashboard back to `idle`.

---

## Running Unit Tests
```bash
pytest test_app.py -v
```