"""
RandomForest Classifier for Vocal Distress Signatures.

Provides model training, serialization, and confidence score prediction (0 - 100%)
over acoustic biomarker feature representations.
"""

from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union
import joblib
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler

from .features import (
    FEATURE_NAMES,
    extract_features,
    extract_features_from_array,
    features_dict_to_vector,
)


DEFAULT_MODEL_PATH = Path(__file__).resolve().parent.parent / "models" / "distress_model.joblib"


class DistressClassifier:
    """
    Vocal distress classifier using a scikit-learn RandomForest model
    to output continuous distress confidence scores (0.0 to 100.0%).
    """

    def __init__(
        self,
        model_path: Optional[Union[str, Path]] = None,
        n_estimators: int = 100,
        max_depth: Optional[int] = 6,
        random_state: int = 42,
    ):
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.random_state = random_state
        self.feature_names = list(FEATURE_NAMES)

        self.model: Optional[RandomForestClassifier] = None
        self.scaler: Optional[StandardScaler] = None

        if model_path is not None:
            self.load(model_path)

    def fit(self, X: np.ndarray, y: np.ndarray) -> "DistressClassifier":
        """
        Fit scaler and RandomForest on feature matrix X and labels y.
        y: binary indicator (1 = distress: fear/sad, 0 = neutral/calm).
        """
        X = np.asarray(X, dtype=np.float32)
        y = np.asarray(y, dtype=np.int32)

        self.scaler = StandardScaler()
        X_scaled = self.scaler.fit_transform(X)

        self.model = RandomForestClassifier(
            n_estimators=self.n_estimators,
            max_depth=self.max_depth,
            random_state=self.random_state,
            class_weight="balanced",
        )
        self.model.fit(X_scaled, y)
        return self

    def save(self, filepath: Union[str, Path] = DEFAULT_MODEL_PATH) -> Path:
        """Serialize trained model, scaler, and feature metadata to a joblib bundle."""
        if self.model is None or self.scaler is None:
            raise ValueError("Cannot save an unfitted model. Call fit() first.")

        target_path = Path(filepath).resolve()
        target_path.parent.mkdir(parents=True, exist_ok=True)

        bundle = {
            "model": self.model,
            "scaler": self.scaler,
            "feature_names": self.feature_names,
            "classes": self.model.classes_,
        }
        joblib.dump(bundle, str(target_path))
        return target_path

    def load(self, filepath: Union[str, Path] = DEFAULT_MODEL_PATH) -> "DistressClassifier":
        """Load trained bundle from a joblib file."""
        target_path = Path(filepath).resolve()
        if not target_path.is_file():
            raise FileNotFoundError(f"Model artifact not found at: {target_path}")

        bundle = joblib.load(str(target_path))
        self.model = bundle["model"]
        self.scaler = bundle["scaler"]
        self.feature_names = bundle.get("feature_names", list(FEATURE_NAMES))
        return self

    def predict_score_from_features(self, features: Union[Dict[str, float], np.ndarray]) -> float:
        """
        Compute distress confidence score (0.0 to 100.0%) from features.
        
        Args:
            features: Dictionary of feature names to values, or a 1D vector.
            
        Returns:
            Continuous confidence score in range [0.0, 100.0].
        """
        if self.model is None or self.scaler is None:
            raise RuntimeError("Model is not loaded or trained. Call load() or fit() first.")

        if isinstance(features, dict):
            vec = features_dict_to_vector(features)
        else:
            vec = np.asarray(features, dtype=np.float32)

        if vec.ndim == 1:
            vec = vec.reshape(1, -1)

        vec_scaled = self.scaler.transform(vec)
        # Class 1 is distress (fear / sad)
        classes = list(self.model.classes_)
        distress_class_idx = classes.index(1) if 1 in classes else 0

        prob = float(self.model.predict_proba(vec_scaled)[0][distress_class_idx])
        return round(prob * 100.0, 2)

    def predict_wav(self, wav_path: Union[str, Path]) -> float:
        """Extract features from a .wav file and return distress confidence score (0-100%)."""
        feats = extract_features(wav_path)
        return self.predict_score_from_features(feats)

    def predict_array(self, y: np.ndarray, sr: int = 16000) -> float:
        """Extract features from raw audio array and return distress confidence score (0-100%)."""
        feats = extract_features_from_array(y, sr=sr)
        return self.predict_score_from_features(feats)