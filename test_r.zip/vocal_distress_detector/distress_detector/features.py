"""
Acoustic Feature Extraction for Vocal Distress Signatures.

Extracts vocal distress biomarkers from audio clips using librosa:
- Pitch (F0) mean and variance via pYIN
- Jitter and shimmer estimates (cycle-to-cycle frequency & amplitude perturbation)
- Spectral centroid (mean and variance) and spectral tilt (dB/kHz)
- Silence/pause ratio via librosa.effects.split
- Low-frequency breath-noise energy ratio (50 - 400 Hz)
"""

from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union
import librosa
import numpy as np


DEFAULT_SAMPLE_RATE = 16000

# Canonical ordered feature list for model input
FEATURE_NAMES: List[str] = [
    "f0_mean",
    "f0_var",
    "jitter",
    "shimmer",
    "spectral_centroid_mean",
    "spectral_centroid_var",
    "spectral_tilt",
    "silence_pause_ratio",
    "breath_noise_energy",
]


def extract_features_from_array(y: np.ndarray, sr: int = DEFAULT_SAMPLE_RATE) -> Dict[str, float]:
    """
    Extract vocal distress acoustic features from a raw 1D audio waveform.
    
    Args:
        y: 1D numpy array of audio samples.
        sr: Sample rate in Hz (default: 16000).
        
    Returns:
        Dictionary mapping feature names to extracted float values.
    """
    y = np.asarray(y, dtype=np.float32).squeeze()
    if y.ndim > 1:
        y = y.mean(axis=-1)

    if len(y) == 0:
        return {name: 0.0 for name in FEATURE_NAMES}

    # Normalize audio amplitude to avoid numerical underflow
    max_amp = float(np.max(np.abs(y)))
    if max_amp > 1e-6:
        y = y / max_amp

    # --------------------------------------------------------------------------
    # 1. Pitch (F0) Mean & Variance via pYIN
    # --------------------------------------------------------------------------
    fmin = librosa.note_to_hz("C2")  # ~65 Hz
    fmax = librosa.note_to_hz("C7")  # ~2093 Hz
    
    try:
        f0, voiced_flag, voiced_probs = librosa.pyin(
            y,
            fmin=fmin,
            fmax=fmax,
            sr=sr,
            frame_length=2048,
            hop_length=512,
        )
    except Exception:
        f0, voiced_flag = None, None

    if f0 is not None and voiced_flag is not None:
        valid_mask = voiced_flag & (~np.isnan(f0)) & (f0 > 0)
        voiced_f0 = f0[valid_mask]
    else:
        voiced_f0 = np.array([])

    if len(voiced_f0) > 0:
        f0_mean = float(np.mean(voiced_f0))
        f0_var = float(np.var(voiced_f0))

        # ----------------------------------------------------------------------
        # 2. Jitter Estimate (local relative cycle-to-cycle period perturbation)
        # ----------------------------------------------------------------------
        periods = 1.0 / voiced_f0
        if len(periods) >= 2:
            period_diffs = np.abs(np.diff(periods))
            jitter = float(np.mean(period_diffs) / (np.mean(periods) + 1e-8))
        else:
            jitter = 0.0
    else:
        f0_mean = 0.0
        f0_var = 0.0
        jitter = 0.0

    # --------------------------------------------------------------------------
    # 3. Shimmer Estimate (local cycle-to-cycle RMS amplitude perturbation)
    # --------------------------------------------------------------------------
    rms = librosa.feature.rms(y=y, hop_length=512)[0]
    if voiced_flag is not None and len(voiced_flag) > 0:
        voiced_idx = np.where(voiced_flag[: len(rms)])[0]
        voiced_rms = rms[voiced_idx]
        if len(voiced_rms) >= 2:
            amp_diffs = np.abs(np.diff(voiced_rms))
            shimmer = float(np.mean(amp_diffs) / (np.mean(voiced_rms) + 1e-8))
        else:
            shimmer = 0.0
    else:
        shimmer = 0.0

    # --------------------------------------------------------------------------
    # 4. Spectral Centroid (Mean & Variance)
    # --------------------------------------------------------------------------
    sc = librosa.feature.spectral_centroid(y=y, sr=sr, hop_length=512)[0]
    spectral_centroid_mean = float(np.mean(sc)) if len(sc) > 0 else 0.0
    spectral_centroid_var = float(np.var(sc)) if len(sc) > 0 else 0.0

    # --------------------------------------------------------------------------
    # 5. Spectral Tilt (slope of power spectrum in dB/kHz)
    # --------------------------------------------------------------------------
    n_fft = min(2048, len(y))
    S = np.abs(librosa.stft(y, n_fft=n_fft, hop_length=512))
    mean_spec = np.mean(S, axis=1)
    freqs = librosa.fft_frequencies(sr=sr, n_fft=n_fft)

    # Avoid DC frequency bin 0
    valid_freq_idx = freqs > 20
    if np.sum(valid_freq_idx) > 2:
        valid_freqs = freqs[valid_freq_idx]
        valid_mag_db = 20.0 * np.log10(mean_spec[valid_freq_idx] + 1e-8)
        # Linear fit: y = slope * freq + intercept
        slope, _ = np.polyfit(valid_freqs, valid_mag_db, 1)
        spectral_tilt = float(slope * 1000.0)  # Convert to dB per kHz
    else:
        spectral_tilt = 0.0

    # --------------------------------------------------------------------------
    # 6. Silence / Pause Ratio via librosa.effects.split
    # --------------------------------------------------------------------------
    try:
        intervals = librosa.effects.split(y, top_db=30)
        active_samples = sum(end - start for start, end in intervals)
        total_samples = max(len(y), 1)
        pause_ratio = float(max(0, total_samples - active_samples) / total_samples)
    except Exception:
        pause_ratio = 0.0

    # --------------------------------------------------------------------------
    # 7. Low-Frequency Breath-Noise Energy Ratio (50 Hz - 400 Hz)
    # --------------------------------------------------------------------------
    breath_mask = (freqs >= 50) & (freqs <= 400)
    breath_energy = np.sum(mean_spec[breath_mask] ** 2)
    total_energy = np.sum(mean_spec ** 2) + 1e-8
    breath_noise_energy = float(breath_energy / total_energy)

    return {
        "f0_mean": f0_mean,
        "f0_var": f0_var,
        "jitter": jitter,
        "shimmer": shimmer,
        "spectral_centroid_mean": spectral_centroid_mean,
        "spectral_centroid_var": spectral_centroid_var,
        "spectral_tilt": spectral_tilt,
        "silence_pause_ratio": pause_ratio,
        "breath_noise_energy": breath_noise_energy,
    }


def extract_features(wav_path: Union[str, Path], sr: int = DEFAULT_SAMPLE_RATE) -> Dict[str, float]:
    """
    Extract vocal distress acoustic features from a .wav audio file.
    
    Args:
        wav_path: Path to the .wav file.
        sr: Target sample rate in Hz (default: 16000).
        
    Returns:
        Dictionary of extracted acoustic features.
    """
    wav_path = Path(wav_path).resolve()
    if not wav_path.is_file():
        raise FileNotFoundError(f"Audio file not found: {wav_path}")

    y, loaded_sr = librosa.load(str(wav_path), sr=sr, mono=True)
    return extract_features_from_array(y, sr=sr)


def features_dict_to_vector(features_dict: Dict[str, float]) -> np.ndarray:
    """Convert feature dictionary to standard ordered numpy 1D vector."""
    return np.array([features_dict.get(name, 0.0) for name in FEATURE_NAMES], dtype=np.float32)