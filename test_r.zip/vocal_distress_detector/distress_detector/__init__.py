"""
Vocal Distress Classification Package.

Acoustic biomarker feature extraction and RandomForest classifier
estimating vocal distress confidence (0-100%).
"""

from .classifier import DistressClassifier
from .features import (
    FEATURE_NAMES,
    extract_features,
    extract_features_from_array,
    features_dict_to_vector,
)
from .predict import predict

__all__ = [
    "predict",
    "DistressClassifier",
    "extract_features",
    "extract_features_from_array",
    "features_dict_to_vector",
    "FEATURE_NAMES",
]