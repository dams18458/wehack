"""
Predict API and CLI.

Provides simple predict(wav_path) -> float function returning
a continuous vocal distress confidence score (0-100%).
"""

import argparse
import sys
from pathlib import Path
from typing import Optional, Union

from .classifier import DEFAULT_MODEL_PATH, DistressClassifier


_DEFAULT_CLASSIFIER: Optional[DistressClassifier] = None


def predict(
    wav_path: Union[str, Path],
    model_path: Optional[Union[str, Path]] = None,
) -> float:
    """
    Load the trained vocal distress model and return the confidence score (0.0 to 100.0%) for a .wav clip.
    
    Args:
        wav_path: Path to the .wav audio file to evaluate.
        model_path: Optional custom path to trained distress_model.joblib.
        
    Returns:
        float: Distress confidence score between 0.0% (calm/neutral) and 100.0% (acute distress).
    """
    global _DEFAULT_CLASSIFIER

    target_model_path = Path(model_path).resolve() if model_path else DEFAULT_MODEL_PATH

    if _DEFAULT_CLASSIFIER is None or model_path is not None:
        if not target_model_path.is_file():
            raise FileNotFoundError(
                f"Trained model artifact not found at '{target_model_path}'. "
                "Please run 'python train.py' to train and save the model first."
            )
        classifier = DistressClassifier(model_path=target_model_path)
        if model_path is None:
            _DEFAULT_CLASSIFIER = classifier
    else:
        classifier = _DEFAULT_CLASSIFIER

    return classifier.predict_wav(wav_path)


def main():
    parser = argparse.ArgumentParser(description="Classify vocal distress confidence for a .wav file.")
    parser.add_argument("wav_path", type=str, help="Path to .wav file.")
    parser.add_argument("--model", type=str, default=None, help="Path to model artifact (default: models/distress_model.joblib).")
    args = parser.parse_args()

    try:
        score = predict(args.wav_path, model_path=args.model)
        print(f"File: {args.wav_path}")
        print(f"Vocal Distress Confidence: {score:.2f}%")
        if score >= 65.0:
            print("Status: HIGH DISTRESS SIGNATURE DETECTED")
        elif score >= 40.0:
            print("Status: MODERATE DISTRESS / ELEVATED EMOTION")
        else:
            print("Status: CALM / NEUTRAL")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()