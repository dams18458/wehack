"""
Unit tests for Acoustic Feature Extraction.
Verifies pYIN F0, jitter, shimmer, spectral centroid/tilt, silence ratio,
and breath noise energy extraction across varied audio scenarios.
"""

import tempfile
from pathlib import Path
import numpy as np
import pytest
import soundfile as sf

from distress_detector.features import (
    FEATURE_NAMES,
    extract_features,
    extract_features_from_array,
    features_dict_to_vector,
)


class TestFeatureExtraction:
    def test_feature_keys_and_types(self):
        sr = 16000
        t = np.linspace(0, 1.5, int(sr * 1.5), endpoint=False)
        y = 0.5 * np.sin(2 * np.pi * 220.0 * t)

        feats = extract_features_from_array(y, sr=sr)
        assert isinstance(feats, dict)
        assert set(feats.keys()) == set(FEATURE_NAMES)

        for name in FEATURE_NAMES:
            val = feats[name]
            assert isinstance(val, float)
            assert not np.isnan(val), f"Feature {name} was NaN"
            assert not np.isinf(val), f"Feature {name} was Inf"

    def test_pure_tone_f0_accuracy(self):
        sr = 16000
        target_f0 = 261.63  # Middle C (C4)
        t = np.linspace(0, 2.0, int(sr * 2.0), endpoint=False)
        y = 0.6 * np.sin(2 * np.pi * target_f0 * t)

        feats = extract_features_from_array(y, sr=sr)
        assert pytest.approx(feats["f0_mean"], abs=5.0) == target_f0
        assert feats["f0_var"] < 5.0
        assert feats["jitter"] < 0.02  # Pure tone has near zero period perturbation

    def test_silence_handling_no_nan(self):
        sr = 16000
        y = np.zeros(int(sr * 1.5), dtype=np.float32)

        feats = extract_features_from_array(y, sr=sr)
        assert feats["f0_mean"] == 0.0
        assert feats["f0_var"] == 0.0
        assert feats["jitter"] == 0.0
        assert feats["shimmer"] == 0.0
        assert not np.isnan(feats["spectral_tilt"])

    def test_silence_pause_ratio(self):
        sr = 16000
        # 1.0s tone followed by 1.0s silence -> ~50% pause ratio
        t = np.linspace(0, 1.0, int(sr * 1.0), endpoint=False)
        tone = 0.5 * np.sin(2 * np.pi * 300.0 * t)
        silence = np.zeros(int(sr * 1.0), dtype=np.float32)
        y = np.concatenate([tone, silence])

        feats = extract_features_from_array(y, sr=sr)
        assert 0.35 <= feats["silence_pause_ratio"] <= 0.65

    def test_breath_noise_energy(self):
        sr = 16000
        t = np.linspace(0, 1.0, int(sr * 1.0), endpoint=False)
        # Tone concentrated at 150 Hz (inside 50-400 Hz breath band)
        low_tone = 0.5 * np.sin(2 * np.pi * 150.0 * t)
        # Tone concentrated at 3000 Hz (outside breath band)
        high_tone = 0.5 * np.sin(2 * np.pi * 3000.0 * t)

        low_feats = extract_features_from_array(low_tone, sr=sr)
        high_feats = extract_features_from_array(high_tone, sr=sr)

        assert low_feats["breath_noise_energy"] > 0.60
        assert high_feats["breath_noise_energy"] < 0.10

    def test_extract_from_wav_file(self):
        sr = 16000
        t = np.linspace(0, 1.0, int(sr * 1.0), endpoint=False)
        y = (0.5 * np.sin(2 * np.pi * 440.0 * t)).astype(np.float32)

        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            temp_path = Path(f.name)

        try:
            sf.write(str(temp_path), y, sr)
            feats = extract_features(temp_path, sr=sr)
            assert pytest.approx(feats["f0_mean"], abs=5.0) == 440.0

            vec = features_dict_to_vector(feats)
            assert isinstance(vec, np.ndarray)
            assert len(vec) == len(FEATURE_NAMES)
        finally:
            if temp_path.is_file():
                temp_path.unlink()