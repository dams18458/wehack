"""
Unit tests for DistressClassifier and predict() API.
Verifies training, probability calibration (0-100%), serialization,
and input validation.
"""

import tempfile
from pathlib import Path
import numpy as np
import pytest
import soundfile as sf

from distress_detector.classifier import DistressClassifier
from distress_detector.features import FEATURE_NAMES
from distress_detector.predict import predict


class TestDistressClassifier:
    @pytest.fixture
    def synthetic_dataset(self):
        """Generate synthetic feature rows representing calm vs distress."""
        np.random.seed(42)
        n_samples = 40
        n_features = len(FEATURE_NAMES)

        # Neutral samples (low F0 ~110, low jitter, low shimmer)
        X_calm = np.random.normal(loc=1.0, scale=0.2, size=(n_samples // 2, n_features))
        y_calm = np.zeros(n_samples // 2, dtype=int)

        # Distress samples (high F0 ~250, higher jitter, higher shimmer)
        X_distress = np.random.normal(loc=3.5, scale=0.3, size=(n_samples // 2, n_features))
        y_distress = np.ones(n_samples // 2, dtype=int)

        X = np.vstack([X_calm, X_distress])
        y = np.concatenate([y_calm, y_distress])
        return X, y

    def test_fit_and_predict_score_range(self, synthetic_dataset):
        X, y = synthetic_dataset
        clf = DistressClassifier(n_estimators=30, random_state=42)
        clf.fit(X, y)

        # Predict calm sample
        calm_sample = np.ones(len(FEATURE_NAMES)) * 1.0
        calm_score = clf.predict_score_from_features(calm_sample)
        assert 0.0 <= calm_score <= 100.0

        # Predict distress sample
        distress_sample = np.ones(len(FEATURE_NAMES)) * 3.5
        distress_score = clf.predict_score_from_features(distress_sample)
        assert 0.0 <= distress_score <= 100.0

        # Distress score must be higher than calm score
        assert distress_score > calm_score

    def test_serialization_save_and_load(self, synthetic_dataset):
        X, y = synthetic_dataset
        clf = DistressClassifier(n_estimators=30, random_state=42)
        clf.fit(X, y)

        sample = np.ones(len(FEATURE_NAMES)) * 2.5
        orig_score = clf.predict_score_from_features(sample)

        with tempfile.TemporaryDirectory() as tmpdir:
            model_file = Path(tmpdir) / "distress_model.joblib"
            clf.save(model_file)
            assert model_file.is_file()

            # Load into new instance
            clf_loaded = DistressClassifier(model_path=model_file)
            loaded_score = clf_loaded.predict_score_from_features(sample)
            assert loaded_score == pytest.approx(orig_score, abs=1e-3)

    def test_predict_function_with_wav(self, synthetic_dataset):
        X, y = synthetic_dataset
        clf = DistressClassifier(n_estimators=30, random_state=42)
        clf.fit(X, y)

        with tempfile.TemporaryDirectory() as tmpdir:
            model_file = Path(tmpdir) / "test_model.joblib"
            clf.save(model_file)

            # Create test WAV
            sr = 16000
            t = np.linspace(0, 1.0, sr, endpoint=False)
            audio = (0.5 * np.sin(2 * np.pi * 200.0 * t)).astype(np.float32)
            wav_file = Path(tmpdir) / "sample.wav"
            sf.write(str(wav_file), audio, sr)

            score = predict(wav_file, model_path=model_file)
            assert isinstance(score, float)
            assert 0.0 <= score <= 100.0