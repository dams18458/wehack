import io
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

import numpy as np
import requests
import soundfile as sf

import help_listener


class TestHelpListener(unittest.TestCase):
    def test_calculate_rms_energy(self):
        # Empty audio
        self.assertEqual(help_listener.calculate_rms_energy(np.zeros(0)), 0.0)

        # Silence / near-zero audio
        silence = np.zeros(16000, dtype=np.float32)
        self.assertEqual(help_listener.calculate_rms_energy(silence), 0.0)

        # Constant amplitude 0.5
        constant = np.full(1000, 0.5, dtype=np.float32)
        self.assertAlmostEqual(help_listener.calculate_rms_energy(constant), 0.5, places=4)

    def test_audio_to_wav_bytes(self):
        audio = np.random.uniform(-0.5, 0.5, 16000).astype(np.float32)
        wav_bytes = help_listener.audio_to_wav_bytes(audio, sample_rate=16000)

        self.assertIsInstance(wav_bytes, bytes)
        self.assertTrue(len(wav_bytes) > 44)  # Has at least WAV header + payload

        # Read back via soundfile
        data, sr = sf.read(io.BytesIO(wav_bytes))
        self.assertEqual(sr, 16000)
        self.assertEqual(len(data), 16000)

    def test_distress_keywords_dictionary_coverage(self):
        # Must have exactly 23 languages (22 Eighth Schedule + English)
        self.assertEqual(len(help_listener.DISTRESS_KEYWORDS), 23)
        expected_languages = [
            "English", "Hindi", "Bengali", "Telugu", "Marathi", "Tamil", "Urdu",
            "Gujarati", "Kannada", "Odia", "Malayalam", "Punjabi", "Assamese",
            "Maithili", "Sanskrit", "Kashmiri", "Nepali", "Sindhi", "Konkani",
            "Dogri", "Manipuri", "Bodo", "Santali"
        ]
        for lang in expected_languages:
            self.assertIn(lang, help_listener.DISTRESS_KEYWORDS)
            pairs = help_listener.DISTRESS_KEYWORDS[lang]
            self.assertTrue(len(pairs) > 0)
            for native, translit in pairs:
                self.assertIsInstance(native, str)
                self.assertIsInstance(translit, str)

    def test_check_distress_keywords(self):
        # English keywords
        res_en = help_listener.check_distress_keywords("Please help me!")
        self.assertTrue(any(m["language"] == "English" and m["term"] == "help" for m in res_en))
        self.assertTrue(any(m["language"] == "English" and m["term"] == "help me" for m in res_en))

        # Hindi transliterated & native script with danda "।" (also shared by Dogri)
        res_hi = help_listener.check_distress_keywords("बचाओ।")
        self.assertTrue(any(m["language"] == "Hindi" and m["term"] == "बचाओ" for m in res_hi))
        self.assertTrue(any(m["language"] == "Dogri" and m["term"] == "बचाओ" for m in res_hi))

        res_hi2 = help_listener.check_distress_keywords("अरे मेरी मदद करो।")
        self.assertTrue(any(m["language"] == "Hindi" and m["term"] == "मदद" for m in res_hi2))

        # Telugu
        res_te = help_listener.check_distress_keywords("దయచేసి కాపాడు!")
        self.assertEqual(res_te, [{"language": "Telugu", "term": "కాపాడు"}])

        # Tamil
        res_ta = help_listener.check_distress_keywords("யாராவது காப்பாத்துங்க.")
        self.assertEqual(res_ta, [{"language": "Tamil", "term": "காப்பாத்துங்க"}])

        # Bengali
        res_bn = help_listener.check_distress_keywords("আমাকে বাঁচাও।")
        self.assertEqual(res_bn, [{"language": "Bengali", "term": "বাঁচাও"}])

        # Kannada
        res_kn = help_listener.check_distress_keywords("ದಯವಿಟ್ಟು ಕಾಪಾಡಿ।")
        self.assertEqual(res_kn, [{"language": "Kannada", "term": "ಕಾಪಾಡಿ"}])

        # Sanskrit
        res_sa = help_listener.check_distress_keywords("हे प्रभो त्राहि!")
        self.assertEqual(res_sa, [{"language": "Sanskrit", "term": "त्राहि"}])

        # Urdu
        res_ur = help_listener.check_distress_keywords("میری مدد کرو")
        self.assertTrue(any(m["language"] == "Urdu" and m["term"] == "مدد" for m in res_ur))

        # Odia
        res_or = help_listener.check_distress_keywords("ମତେ ବଞ୍ଚାଅ!")
        self.assertTrue(any(m["language"] == "Odia" and m["term"] == "ବଞ୍ଚାଅ" for m in res_or))

        # Malayalam
        res_ml = help_listener.check_distress_keywords("എന്നെ രക്ഷിക്കൂ")
        self.assertTrue(any(m["language"] == "Malayalam" and m["term"] == "രക്ഷിക്കൂ" for m in res_ml))

        # Santali (Ol Chiki)
        res_sat = help_listener.check_distress_keywords("ᱜᱚᱲᱚ")
        self.assertEqual(res_sat, [{"language": "Santali", "term": "ᱜᱚᱲᱚ"}])

        # Non-distress benign speech
        self.assertEqual(help_listener.check_distress_keywords("Good morning everyone, welcome to the demo."), [])
        self.assertEqual(help_listener.check_distress_keywords(""), [])

    @patch("help_listener.requests.post")
    def test_query_sarvam_stt(self, mock_post):
        mock_resp = MagicMock()
        mock_resp.json.return_value = {
            "transcript": "bachao bachao",
            "language_code": "hi-IN",
            "language_probability": 0.98,
        }
        mock_resp.raise_for_status = MagicMock()
        mock_post.return_value = mock_resp

        fake_wav = b"RIFFfakeWAVdata"
        result = help_listener.query_sarvam_stt(fake_wav, api_key="test_api_key")

        mock_post.assert_called_once()
        args, kwargs = mock_post.call_args
        self.assertEqual(args[0], "https://api.sarvam.ai/speech-to-text")
        self.assertEqual(kwargs["headers"]["api-subscription-key"], "test_api_key")
        self.assertEqual(kwargs["data"]["model"], "saaras:v3")
        self.assertEqual(kwargs["data"]["mode"], "transcribe")
        self.assertIn("file", kwargs["files"])
        self.assertEqual(result["transcript"], "bachao bachao")

    @patch("help_listener.requests.post")
    def test_notify_dashboard(self, mock_post):
        mock_post.return_value = MagicMock(status_code=200)
        help_listener.notify_dashboard(
            confidence=95.0,
            audio_path="evidence/test.wav",
            language="Hindi",
            contact="Voice Trigger (Sarvam)",
            dashboard_url="http://127.0.0.1:5000/trigger",
        )
        mock_post.assert_called_once()
        args, kwargs = mock_post.call_args
        self.assertEqual(args[0], "http://127.0.0.1:5000/trigger")
        self.assertEqual(kwargs["json"]["confidence"], 95.0)
        self.assertEqual(kwargs["json"]["language"], "Hindi")
        self.assertEqual(kwargs["json"]["contact"], "Voice Trigger (Sarvam)")
        self.assertEqual(kwargs["json"]["audio_path"], "evidence/test.wav")
        self.assertIn("timestamp", kwargs["json"])

    @patch("help_listener.requests.post", side_effect=requests.exceptions.ConnectionError("Offline"))
    def test_notify_dashboard_silent_failure(self, mock_post):
        # Must not raise an exception
        try:
            help_listener.notify_dashboard(95.0, "test.wav")
        except Exception as e:
            self.fail(f"notify_dashboard raised unexpected exception: {e}")

    @patch("help_listener.notify_dashboard")
    @patch("help_listener.query_sarvam_stt")
    def test_help_listener_process_chunk_energy_gating(self, mock_stt, mock_notify):
        listener = help_listener.HelpListener(
            api_key="mock_key",
            energy_threshold=0.02,
            evidence_dir="evidence",
        )

        # 1. Silent chunk: RMS < 0.02 -> skips API call completely
        silent_chunk = np.full(48000, 0.005, dtype=np.float32)
        transcript, matches = listener.process_chunk(silent_chunk)

        self.assertIsNone(transcript)
        self.assertEqual(matches, [])
        mock_stt.assert_not_called()
        self.assertEqual(listener._api_call_count, 0)

        # 2. Active speech chunk with keyword -> calls API and triggers
        mock_stt.return_value = {
            "transcript": "Please help me quickly",
            "language_probability": 0.96,
        }
        speech_chunk = np.full(48000, 0.05, dtype=np.float32)
        transcript, matches = listener.process_chunk(speech_chunk)

        mock_stt.assert_called_once()
        self.assertEqual(listener._api_call_count, 1)
        self.assertTrue(any(m["language"] == "English" and "help" in m["term"] for m in matches))
        mock_notify.assert_called_once()
        _, kwargs = mock_notify.call_args
        self.assertEqual(kwargs["confidence"], 96.0)
        self.assertEqual(kwargs["language"], "English")

        # 3. Repeat active chunk within cooldown (cooldown=8.0s) -> API called, but alert suppressed
        mock_notify.reset_mock()
        mock_stt.return_value = {
            "transcript": "help again",
            "language_probability": 0.90,
        }
        transcript2, matches2 = listener.process_chunk(speech_chunk)
        self.assertEqual(listener._api_call_count, 2)
        self.assertTrue(any(m["language"] == "English" and "help" in m["term"] for m in matches2))
        # Dashboard notification must NOT be called due to cooldown
        mock_notify.assert_not_called()


if __name__ == "__main__":
    unittest.main()
