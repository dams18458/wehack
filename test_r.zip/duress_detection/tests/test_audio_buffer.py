"""
Unit tests for the CircularAudioBuffer.
Verifies rolling 30-second retention, chronological order, FIFO rollover,
and WAV snapshot persistence on trigger.
"""

import tempfile
from pathlib import Path
import numpy as np
import pytest
import soundfile as sf

from duress_detector.audio_buffer import CircularAudioBuffer


class TestCircularAudioBuffer:
    def test_buffer_initialization(self):
        sr = 16000
        cap_sec = 30.0
        buf = CircularAudioBuffer(capacity_seconds=cap_sec, sample_rate=sr)
        assert buf.capacity_samples == int(sr * cap_sec)
        assert buf.duration_seconds == 0.0
        assert buf.total_samples_written == 0
        assert len(buf.get_snapshot()) == 0

    def test_partial_fill(self):
        sr = 16000
        buf = CircularAudioBuffer(capacity_seconds=30.0, sample_rate=sr)
        # Push 5 seconds of audio
        five_sec = np.linspace(0.1, 0.5, sr * 5, dtype=np.float32)
        buf.append(five_sec)

        assert buf.total_samples_written == sr * 5
        assert buf.current_samples_count == sr * 5
        assert pytest.approx(buf.duration_seconds, 0.01) == 5.0

        snapshot = buf.get_snapshot()
        assert len(snapshot) == sr * 5
        np.testing.assert_allclose(snapshot, five_sec, atol=1e-6)

    def test_exact_capacity_fill(self):
        sr = 1000
        cap_sec = 3.0  # 3000 samples
        buf = CircularAudioBuffer(capacity_seconds=cap_sec, sample_rate=sr)
        data = np.arange(3000, dtype=np.float32)
        buf.append(data)

        assert buf.current_samples_count == 3000
        snapshot = buf.get_snapshot()
        assert len(snapshot) == 3000
        np.testing.assert_allclose(snapshot, data)

    def test_rollover_retains_only_last_30_seconds(self):
        """
        Verify that pushing 45 seconds into a 30-second buffer discards the
        first 15 seconds and retains strictly the most recent 30 seconds
        in correct chronological order.
        """
        sr = 1000  # 1kHz for test speed
        cap_sec = 30.0
        buf = CircularAudioBuffer(capacity_seconds=cap_sec, sample_rate=sr)

        # 45 seconds total = 45,000 samples with monotonic sequence [0, 1, 2, ... 44999]
        total_samples = 45000
        all_data = np.arange(total_samples, dtype=np.float32)

        # Append in chunks of 5 seconds (5000 samples)
        chunk_size = 5000
        for i in range(0, total_samples, chunk_size):
            buf.append(all_data[i : i + chunk_size])

        assert buf.total_samples_written == 45000
        assert buf.current_samples_count == 30000
        assert pytest.approx(buf.duration_seconds, 0.01) == 30.0

        snapshot = buf.get_snapshot()
        assert len(snapshot) == 30000

        # Snapshot must equal exactly the trailing 30,000 samples: [15000, 15001, ..., 44999]
        expected_trailing = all_data[-30000:]
        np.testing.assert_array_equal(snapshot, expected_trailing)

    def test_oversized_single_chunk_append(self):
        sr = 1000
        buf = CircularAudioBuffer(capacity_seconds=10.0, sample_rate=sr)
        # Push single chunk of 25 seconds
        data = np.arange(25000, dtype=np.float32)
        buf.append(data)

        assert buf.current_samples_count == 10000
        snapshot = buf.get_snapshot()
        assert len(snapshot) == 10000
        np.testing.assert_array_equal(snapshot, data[-10000:])

    def test_save_to_wav_on_trigger(self):
        """
        Verify that save_to_wav correctly creates a valid 16-bit PCM WAV file
        with the exact expected sample rate, duration, and audio data.
        """
        sr = 16000
        buf = CircularAudioBuffer(capacity_seconds=5.0, sample_rate=sr)

        # Generate 3 seconds of 440 Hz sine wave
        t = np.linspace(0, 3.0, int(sr * 3.0), endpoint=False, dtype=np.float32)
        sine_wave = 0.6 * np.sin(2 * np.pi * 440.0 * t)
        buf.append(sine_wave)

        with tempfile.TemporaryDirectory() as tmpdir:
            wav_path = Path(tmpdir) / "evidence" / "test_alert.wav"
            saved_path = buf.save_to_wav(wav_path)

            assert saved_path.is_file()
            assert saved_path.stat().st_size > 0

            # Read back with soundfile and verify properties
            read_data, read_sr = sf.read(str(saved_path))
            assert read_sr == sr
            assert len(read_data) == len(sine_wave)
            # PCM 16 has 16-bit quantization (~1e-4 tolerance)
            np.testing.assert_allclose(read_data, sine_wave, atol=1e-3)

    def test_clear_buffer(self):
        sr = 16000
        buf = CircularAudioBuffer(capacity_seconds=10.0, sample_rate=sr)
        buf.append(np.ones(5000, dtype=np.float32))
        assert buf.current_samples_count == 5000

        buf.clear()
        assert buf.current_samples_count == 0
        assert len(buf.get_snapshot()) == 0