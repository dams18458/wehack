import unittest
from unittest.mock import MagicMock, patch
from pathlib import Path
import requests

import listen


class TestDashboardNotification(unittest.TestCase):
    @patch("listen.requests.post")
    def test_notify_dashboard_success(self, mock_post):
        mock_post.return_value = MagicMock(status_code=200)
        listen.notify_dashboard(confidence=0.85, audio_path="evidence/test.wav", contact="Guardian")
        mock_post.assert_called_once()
        args, kwargs = mock_post.call_args
        self.assertEqual(args[0], "http://127.0.0.1:5000/trigger")
        self.assertEqual(kwargs["timeout"], 2)
        payload = kwargs["json"]
        self.assertEqual(payload["contact"], "Guardian")
        self.assertEqual(payload["confidence"], 0.85)
        self.assertEqual(payload["audio_path"], "evidence/test.wav")
        self.assertIn("timestamp", payload)

    @patch("listen.requests.post", side_effect=requests.exceptions.ConnectTimeout("Unreachable"))
    def test_notify_dashboard_silent_failure_timeout(self, mock_post):
        try:
            listen.notify_dashboard(confidence=0.75, audio_path="evidence/test.wav")
        except Exception as e:
            self.fail(f"notify_dashboard raised unexpected exception: {e}")

    @patch("listen.requests.post", side_effect=requests.exceptions.ConnectionError("Server Down"))
    def test_notify_dashboard_silent_failure_connection(self, mock_post):
        try:
            listen.notify_dashboard(confidence=0.75, audio_path="evidence/test.wav")
        except Exception as e:
            self.fail(f"notify_dashboard raised unexpected exception: {e}")

    @patch("listen.notify_dashboard")
    @patch("listen.base_trigger_action")
    def test_trigger_action_calls_notify_dtw_confidence(self, mock_base_action, mock_notify):
        fake_path = Path("evidence/duress_evidence_123.wav")
        mock_base_action.return_value = fake_path
        fake_buffer = MagicMock()

        # Test example from prompt: dtw_dist = 4.8 with threshold 32.0 gives 85.0%
        ret = listen.trigger_action(
            buffer=fake_buffer,
            evidence_dir="evidence",
            log_path="alerts.log",
            metadata={"dtw_dist": 4.8, "energy_sim": 0.93},
        )
        self.assertEqual(ret, fake_path)
        mock_notify.assert_called_with(
            confidence=85.0,
            audio_path=str(fake_path),
        )

        # Test perfect match: dtw_dist = 0.0 -> 100.0%
        listen.trigger_action(
            buffer=fake_buffer,
            metadata={"dtw_dist": 0.0},
        )
        mock_notify.assert_called_with(
            confidence=100.0,
            audio_path=str(fake_path),
        )

        # Test over threshold: dtw_dist >= dtw_threshold -> 0.0%
        listen.trigger_action(
            buffer=fake_buffer,
            metadata={"dtw_dist": 40.0},
        )
        mock_notify.assert_called_with(
            confidence=0.0,
            audio_path=str(fake_path),
        )

    def test_parse_args_verbose_flag(self):
        # Default without -v
        with patch("sys.argv", ["listen.py"]):
            args = listen.parse_args()
            self.assertFalse(args.verbose)

        # With -v
        with patch("sys.argv", ["listen.py", "-v"]):
            args_short = listen.parse_args()
            self.assertTrue(args_short.verbose)

        # With --verbose
        with patch("sys.argv", ["listen.py", "--verbose"]):
            args_long = listen.parse_args()
            self.assertTrue(args_long.verbose)

    def test_verbose_evaluate_match_printing(self):
        from io import StringIO
        from duress_detector.matcher import MatchResult
        import duress_detector.detector as detector_module

        out = StringIO()
        dummy_result = MatchResult(
            is_match=False,
            dtw_distance=95.234,
            energy_similarity=0.182,
            dtw_pass=False,
            energy_pass=False,
            dtw_threshold=32.0,
            energy_threshold=0.60,
            summary="test",
        )

        orig_eval = detector_module.evaluate_match
        try:
            detector_module.evaluate_match = MagicMock(return_value=dummy_result)
            mocked_orig = detector_module.evaluate_match

            def verbose_eval(*m_args, **m_kwargs):
                res = mocked_orig(*m_args, **m_kwargs)
                print(f"[DTW: {res.dtw_distance:.1f}, Energy: {res.energy_similarity:.2f}]", file=out)
                return res

            detector_module.evaluate_match = verbose_eval
            res = detector_module.evaluate_match(None, None, {})
            self.assertEqual(res, dummy_result)
            self.assertIn("[DTW: 95.2, Energy: 0.18]", out.getvalue())
        finally:
            detector_module.evaluate_match = orig_eval


if __name__ == "__main__":
    unittest.main()

