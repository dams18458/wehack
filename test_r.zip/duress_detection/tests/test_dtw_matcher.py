"""
Unit tests for the DTW and Energy Envelope Matcher.

Uses purely synthetic feature vectors and envelopes (no real audio dependencies)
to verify that Dynamic Time Warping and envelope correlation correctly
discriminate similar vs. dissimilar time-series sequences.
"""

import numpy as np
import pytest

from duress_detector.matcher import (
    DTW_DISTANCE_THRESHOLD,
    ENERGY_SIMILARITY_THRESHOLD,
    compute_dtw_distance,
    compute_envelope_similarity,
    evaluate_match,
)


class TestDTWMatcherSynthetic:
    @pytest.fixture
    def base_synthetic_sequence(self):
        """
        Generate a smooth synthetic multi-dimensional feature sequence (30 frames, 13 features).
        Simulates an MFCC trajectory over time.
        """
        n_frames = 30
        n_features = 13
        t = np.linspace(0, 2 * np.pi, n_frames)
        features = np.zeros((n_frames, n_features), dtype=np.float64)

        for d in range(n_features):
            phase = d * 0.4
            features[:, d] = np.sin(t + phase) + 0.5 * np.cos(2 * t + phase)

        return features

    @pytest.fixture
    def time_warped_similar_sequence(self, base_synthetic_sequence):
        """
        Create a time-warped and slightly noisy version of the base sequence.
        Some frames are elongated (repeated) and others skipped, mimicking non-linear speech speed variation.
        """
        base = base_synthetic_sequence
        n_frames, n_features = base.shape

        # Non-linear warp: repeat frames [5, 6], stretch [15-20], add small Gaussian jitter
        warp_indices = []
        for i in range(n_frames):
            warp_indices.append(i)
            if 5 <= i <= 8 or 18 <= i <= 22:
                warp_indices.append(i)  # Time dilation

        warped = base[warp_indices].copy()
        # Add small zero-mean Gaussian noise (SNR > 30dB)
        np.random.seed(42)
        noise = np.random.normal(0, 0.05, warped.shape)
        return (warped + noise).astype(np.float64)

    @pytest.fixture
    def dissimilar_synthetic_sequence(self):
        """
        Create a completely dissimilar synthetic sequence with inverted and orthogonal frequency components.
        """
        n_frames = 35
        n_features = 13
        t = np.linspace(0, 8 * np.pi, n_frames)  # 4x higher frequency
        features = np.zeros((n_frames, n_features), dtype=np.float64)

        for d in range(n_features):
            features[:, d] = -np.cos(t + d) + np.sign(np.sin(2 * t))

        return features

    def test_dtw_identical_sequences(self, base_synthetic_sequence):
        """Identical sequences must have exactly 0.0 DTW distance."""
        norm_dist, raw_dist, path_len = compute_dtw_distance(
            base_synthetic_sequence, base_synthetic_sequence
        )
        assert norm_dist == pytest.approx(0.0, abs=1e-6)
        assert raw_dist == pytest.approx(0.0, abs=1e-6)
        assert path_len == len(base_synthetic_sequence)

    def test_dtw_discriminates_similar_vs_dissimilar(
        self,
        base_synthetic_sequence,
        time_warped_similar_sequence,
        dissimilar_synthetic_sequence,
    ):
        """
        Confirm DTW correctly computes a low distance for a time-warped similar
        sequence, and a significantly higher distance for a dissimilar sequence.
        """
        norm_dist_similar, _, _ = compute_dtw_distance(
            base_synthetic_sequence, time_warped_similar_sequence
        )
        norm_dist_dissimilar, _, _ = compute_dtw_distance(
            base_synthetic_sequence, dissimilar_synthetic_sequence
        )

        # Similar sequence should have small distance
        assert norm_dist_similar < 1.0
        # Dissimilar sequence should have large distance
        assert norm_dist_dissimilar > 4.0

        # Contrast ratio should be at least 4x
        assert norm_dist_dissimilar > (norm_dist_similar * 4.0)

    def test_empty_sequence_dtw(self, base_synthetic_sequence):
        """Empty sequences should return infinity without crashing."""
        norm_dist, raw_dist, path_len = compute_dtw_distance(
            np.zeros((0, 13)), base_synthetic_sequence
        )
        assert norm_dist == float("inf")

    def test_energy_envelope_synthetic_correlation(self):
        """
        Verify that energy envelope correlation detects matching cadence
        (e.g. double burst / two syllables) and rejects mismatched rhythm.
        """
        # Two-pulse burst envelope (e.g. two sharp exhales or two-syllable phrase)
        frames = 50
        x = np.arange(frames)
        peak1 = np.exp(-((x - 15) ** 2) / 10.0)
        peak2 = np.exp(-((x - 35) ** 2) / 10.0)
        template_envelope = peak1 + peak2

        # Similar envelope: slightly different timing/duration (40 frames)
        x_sim = np.arange(40)
        p1_sim = np.exp(-((x_sim - 12) ** 2) / 8.0)
        p2_sim = np.exp(-((x_sim - 28) ** 2) / 8.0)
        similar_envelope = p1_sim + p2_sim

        # Dissimilar envelope: single central peak
        x_dis = np.arange(50)
        dissimilar_envelope = np.exp(-((x_dis - 25) ** 2) / 15.0)

        # Flat envelope (constant background noise)
        flat_envelope = np.ones(50) * 0.1

        sim_score = compute_envelope_similarity(similar_envelope, template_envelope)
        dis_score = compute_envelope_similarity(dissimilar_envelope, template_envelope)
        flat_score = compute_envelope_similarity(flat_envelope, template_envelope)

        assert sim_score > 0.85, f"Expected high similarity for matching cadence, got {sim_score}"
        assert dis_score < 0.30, f"Expected low similarity for single-peak mismatch, got {dis_score}"
        assert flat_score == 0.0, f"Flat background noise envelope must have 0 similarity, got {flat_score}"

    def test_evaluate_match_dual_gate(
        self,
        base_synthetic_sequence,
        time_warped_similar_sequence,
        dissimilar_synthetic_sequence,
    ):
        """
        Verify evaluate_match requires BOTH the DTW distance and Energy similarity
        thresholds to be satisfied.
        """
        frames = 40
        x = np.arange(frames)
        two_peak_env = np.exp(-((x - 10) ** 2) / 8.0) + np.exp(-((x - 30) ** 2) / 8.0)

        fake_template = {
            "mfcc": base_synthetic_sequence,
            "energy_envelope": two_peak_env,
            "duration": 1.5,
            "sample_rate": 16000,
        }

        # Case 1: Both pass (similar MFCC + matching cadence)
        res_pass = evaluate_match(
            sample_mfcc=time_warped_similar_sequence,
            sample_envelope=two_peak_env,
            template=fake_template,
            dtw_threshold=1.5,
            energy_threshold=0.7,
        )
        assert res_pass.is_match is True
        assert res_pass.dtw_pass is True
        assert res_pass.energy_pass is True

        # Case 2: MFCC passes, but energy cadence fails (e.g. flat envelope)
        flat_env = np.ones(frames) * 0.05
        res_fail_energy = evaluate_match(
            sample_mfcc=time_warped_similar_sequence,
            sample_envelope=flat_env,
            template=fake_template,
            dtw_threshold=1.5,
            energy_threshold=0.7,
        )
        assert res_fail_energy.is_match is False
        assert res_fail_energy.dtw_pass is True
        assert res_fail_energy.energy_pass is False

        # Case 3: Energy passes, but MFCC fails (dissimilar spectral sequence)
        res_fail_mfcc = evaluate_match(
            sample_mfcc=dissimilar_synthetic_sequence,
            sample_envelope=two_peak_env,
            template=fake_template,
            dtw_threshold=1.5,
            energy_threshold=0.7,
        )
        assert res_fail_mfcc.is_match is False
        assert res_fail_mfcc.dtw_pass is False
        assert res_fail_mfcc.energy_pass is True