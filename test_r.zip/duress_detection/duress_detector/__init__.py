"""
Duress Detection System
Privacy-first, 100% on-device duress trigger detection module using MFCC, FastDTW,
and rolling circular audio buffer.
"""

from .audio_buffer import CircularAudioBuffer
from .features import (
    extract_mfcc,
    extract_energy_envelope,
    create_enrolled_template,
    save_enrolled_template,
    load_enrolled_template,
    trim_silence,
)
from .matcher import (
    compute_dtw_distance,
    compute_envelope_similarity,
    evaluate_match,
    DTW_DISTANCE_THRESHOLD,
    ENERGY_SIMILARITY_THRESHOLD,
    MatchResult,
)
from .trigger import trigger_action
from .detector import LiveDetectionPipeline

__all__ = [
    "CircularAudioBuffer",
    "extract_mfcc",
    "extract_energy_envelope",
    "create_enrolled_template",
    "save_enrolled_template",
    "load_enrolled_template",
    "trim_silence",
    "compute_dtw_distance",
    "compute_envelope_similarity",
    "evaluate_match",
    "DTW_DISTANCE_THRESHOLD",
    "ENERGY_SIMILARITY_THRESHOLD",
    "MatchResult",
    "trigger_action",
    "LiveDetectionPipeline",
]