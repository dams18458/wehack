"""
Thread-Safe In-Memory Circular Audio Buffer.

Maintains a rolling buffer of the last N seconds of audio (default: 30s)
without writing anything to disk during normal listening.
Audio is only persisted to disk if an explicit trigger event occurs.
"""

import threading
from pathlib import Path
from typing import Optional, Union
import numpy as np
import soundfile as sf


class CircularAudioBuffer:
    """
    Thread-safe rolling circular audio buffer maintaining the most recent audio samples.
    """

    def __init__(
        self,
        capacity_seconds: float = 30.0,
        sample_rate: int = 16000,
        channels: int = 1,
        dtype: np.dtype = np.float32,
    ):
        if capacity_seconds <= 0:
            raise ValueError("capacity_seconds must be positive.")
        if sample_rate <= 0:
            raise ValueError("sample_rate must be positive.")

        self.capacity_seconds = float(capacity_seconds)
        self.sample_rate = int(sample_rate)
        self.channels = int(channels)
        self.capacity_samples = int(round(self.capacity_seconds * self.sample_rate))
        self.dtype = np.dtype(dtype)

        # Internal pre-allocated ring buffer
        if self.channels == 1:
            self._buffer = np.zeros(self.capacity_samples, dtype=self.dtype)
        else:
            self._buffer = np.zeros((self.capacity_samples, self.channels), dtype=self.dtype)

        self._write_pos = 0
        self._total_samples_written = 0
        self._lock = threading.Lock()

    @property
    def total_samples_written(self) -> int:
        """Total number of samples ingested over the buffer's lifetime."""
        with self._lock:
            return self._total_samples_written

    @property
    def current_samples_count(self) -> int:
        """Current number of active samples currently retained in the buffer."""
        with self._lock:
            return min(self._total_samples_written, self.capacity_samples)

    @property
    def duration_seconds(self) -> float:
        """Current duration in seconds of audio in the buffer."""
        return self.current_samples_count / self.sample_rate

    def append(self, data: np.ndarray) -> None:
        """
        Append new audio data to the rolling ring buffer. Thread-safe.
        
        Args:
            data: numpy array of audio samples (1D mono or 2D [samples, channels]).
        """
        if data is None or len(data) == 0:
            return

        data = np.asarray(data, dtype=self.dtype)
        if self.channels == 1 and data.ndim > 1:
            data = data.squeeze()
            if data.ndim > 1:
                # Average multi-channel down to mono if necessary
                data = data.mean(axis=-1)

        num_samples = len(data)
        if num_samples == 0:
            return

        with self._lock:
            if num_samples >= self.capacity_samples:
                # Incoming chunk is larger than buffer capacity: keep only trailing portion
                data_to_write = data[-self.capacity_samples :]
                self._buffer[:] = data_to_write
                self._write_pos = 0
                self._total_samples_written += num_samples
                return

            first_chunk_len = min(num_samples, self.capacity_samples - self._write_pos)
            self._buffer[self._write_pos : self._write_pos + first_chunk_len] = data[:first_chunk_len]

            overflow = num_samples - first_chunk_len
            if overflow > 0:
                self._buffer[:overflow] = data[first_chunk_len:]
                self._write_pos = overflow
            else:
                self._write_pos = (self._write_pos + first_chunk_len) % self.capacity_samples

            self._total_samples_written += num_samples

    def get_snapshot(self) -> np.ndarray:
        """
        Return a contiguous copy of the last rolling N seconds in chronological order.
        
        Returns:
            numpy array of samples from oldest to newest.
        """
        with self._lock:
            if self._total_samples_written == 0:
                return np.array([], dtype=self.dtype)

            if self._total_samples_written < self.capacity_samples:
                # Buffer has not wrapped yet
                return self._buffer[: self._write_pos].copy()

            # Buffer has wrapped: chronological order starts at _write_pos
            return np.concatenate((self._buffer[self._write_pos :], self._buffer[: self._write_pos])).copy()

    def save_to_wav(self, filepath: Union[str, Path]) -> Path:
        """
        Export the current buffer snapshot to a 16-bit PCM WAV file.
        Creates parent directories if necessary.
        
        Args:
            filepath: Target file destination for the .wav file.
            
        Returns:
            Resolved Path of the saved file.
        """
        target_path = Path(filepath).resolve()
        target_path.parent.mkdir(parents=True, exist_ok=True)

        snapshot = self.get_snapshot()
        if len(snapshot) == 0:
            # If buffer is empty, write 0.1s silence
            snapshot = np.zeros(int(self.sample_rate * 0.1), dtype=np.float32)

        # Clip float audio to [-1.0, 1.0] to prevent overflow distortion
        snapshot = np.clip(snapshot, -1.0, 1.0)

        sf.write(str(target_path), snapshot, self.sample_rate, subtype="PCM_16")
        return target_path

    def clear(self) -> None:
        """Reset buffer contents to zero."""
        with self._lock:
            self._buffer.fill(0)
            self._write_pos = 0
            self._total_samples_written = 0