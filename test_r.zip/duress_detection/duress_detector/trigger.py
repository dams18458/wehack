"""
Trigger Action Implementation.

Handles execution when duress conditions are detected:
1. Logs timestamped event to alerts.log
2. Prints "ALERT TRIGGERED" to console
3. Flushes rolling 30-second circular audio buffer to /evidence/duress_evidence_<timestamp>.wav
"""

from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional, Union

from .audio_buffer import CircularAudioBuffer


def trigger_action(
    buffer: CircularAudioBuffer,
    evidence_dir: Union[str, Path] = "evidence",
    log_path: Union[str, Path] = "alerts.log",
    metadata: Optional[Dict[str, Any]] = None,
) -> Path:
    """
    Execute alert procedures upon confirmed duress detection.
    
    Args:
        buffer: CircularAudioBuffer holding the last rolling 30 seconds of audio.
        evidence_dir: Directory where evidence .wav files should be written.
        log_path: Filepath where alert log entries are appended.
        metadata: Optional dictionary of detection metrics (DTW score, energy score, etc.).
        
    Returns:
        Path to the saved evidence .wav file.
    """
    now = datetime.now()
    log_timestamp = now.strftime("%Y-%m-%d %H:%M:%S")
    file_timestamp = now.strftime("%Y%m%d_%H%M%S_%f")[:19]  # Include milliseconds

    # 1. Ensure evidence directory exists and save buffer snapshot to .wav
    evidence_path = Path(evidence_dir).resolve() / f"duress_evidence_{file_timestamp}.wav"
    saved_file = buffer.save_to_wav(evidence_path)

    # 2. Append timestamped entry to alerts.log
    log_file = Path(log_path).resolve()
    log_file.parent.mkdir(parents=True, exist_ok=True)

    meta_parts = []
    if metadata:
        for k, v in metadata.items():
            if isinstance(v, float):
                meta_parts.append(f"{k}={v:.2f}")
            else:
                meta_parts.append(f"{k}={v}")
    meta_str = " | ".join(meta_parts) if meta_parts else "No metadata"

    log_entry = f"[{log_timestamp}] ALERT TRIGGERED | Evidence: {saved_file.name} | {meta_str}\n"
    with open(log_file, "a", encoding="utf-8") as f:
        f.write(log_entry)

    # 3. Print the required alert notification to console
    print("ALERT TRIGGERED")

    return saved_file