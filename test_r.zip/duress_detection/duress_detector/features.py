"""
Audio Feature Extraction and Enrollment Template Processing.

Extracts MFCC features and RMS energy envelopes using librosa, performs silence trimming,
and builds time-aligned averaged templates from multiple enrollment samples.
"""

from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union
import librosa
import numpy as np


DEFAULT_SAMPLE_RATE = 16000
DEFAULT_N_MFCC = 13
DEFAULT_HOP_LENGTH = 512
DEFAULT_N_FFT = 1024


def trim_silence(y: np.ndarray, top_db: float = 25.0) -> Tuple[np.ndarray, Tuple[int, int]]:
    """
    Trim leading and trailing silence from an audio signal using librosa.
    
    Args:
        y: Audio time-series (1D numpy array).
        top_db: The threshold (in decibels) below reference to consider as silence.
        
    Returns:
        (trimmed_audio, (start_idx, end_idx))
    """
    if len(y) == 0:
        return y, (0, 0)
    trimmed, index = librosa.effects.trim(y, top_db=top_db)
    if len(trimmed) == 0:
        return y, (0, len(y))
    return trimmed, (int(index[0]), int(index[1]))


def resample_sequence_1d(signal: np.ndarray, target_length: int) -> np.ndarray:
    """
    Resample a 1D sequence to target_length using linear interpolation.
    """
    if len(signal) == target_length:
        return signal.copy()
    if len(signal) <= 1 or target_length <= 1:
        return np.resize(signal, target_length)

    x_old = np.linspace(0.0, 1.0, len(signal))
    x_new = np.linspace(0.0, 1.0, target_length)
    return np.interp(x_new, x_old, signal)


def resample_sequence_2d(matrix: np.ndarray, target_length: int) -> np.ndarray:
    """
    Resample a 2D sequence of shape (time_frames, features) along the time axis.
    """
    time_frames, num_features = matrix.shape
    if time_frames == target_length:
        return matrix.copy()

    resampled = np.zeros((target_length, num_features), dtype=matrix.dtype)
    for col in range(num_features):
        resampled[:, col] = resample_sequence_1d(matrix[:, col], target_length)
    return resampled


def extract_mfcc(
    y: np.ndarray,
    sr: int = DEFAULT_SAMPLE_RATE,
    n_mfcc: int = DEFAULT_N_MFCC,
    hop_length: int = DEFAULT_HOP_LENGTH,
    n_fft: int = DEFAULT_N_FFT,
    standardize: bool = False,
) -> np.ndarray:
    """
    Extract MFCC feature matrix from audio.
    
    Returns:
        2D numpy array of shape (time_frames, n_mfcc).
    """
    if len(y) == 0:
        return np.zeros((0, n_mfcc), dtype=np.float32)

    # Compute MFCCs: shape is (n_mfcc, time_frames)
    mfcc = librosa.feature.mfcc(
        y=y.astype(np.float32),
        sr=sr,
        n_mfcc=n_mfcc,
        hop_length=hop_length,
        n_fft=min(n_fft, len(y)),
    )

    # Transpose so time is along axis 0: shape (time_frames, n_mfcc)
    mfcc_t = mfcc.T

    if standardize and len(mfcc_t) > 1:
        # Cepstral Mean Subtraction (CMS)
        mean = np.mean(mfcc_t, axis=0, keepdims=True)
        mfcc_t = mfcc_t - mean

    return mfcc_t.astype(np.float32)


def extract_energy_envelope(
    y: np.ndarray,
    hop_length: int = DEFAULT_HOP_LENGTH,
    normalize: bool = True,
) -> np.ndarray:
    """
    Compute RMS energy envelope from audio.
    
    Returns:
        1D numpy array of RMS energy per frame.
    """
    if len(y) == 0:
        return np.zeros(0, dtype=np.float32)

    rms = librosa.feature.rms(y=y.astype(np.float32), hop_length=hop_length)[0]

    if normalize and len(rms) > 0:
        max_val = np.max(rms)
        if max_val > 1e-7:
            rms = rms / max_val

    return rms.astype(np.float32)


def create_enrolled_template(
    samples: List[np.ndarray],
    sr: int = DEFAULT_SAMPLE_RATE,
    n_mfcc: int = DEFAULT_N_MFCC,
    hop_length: int = DEFAULT_HOP_LENGTH,
    n_fft: int = DEFAULT_N_FFT,
    trim_silence_flag: bool = True,
) -> Dict[str, Union[np.ndarray, float, int]]:
    """
    Process multiple enrollment audio samples, extract MFCCs and energy envelopes,
    align them in time, and compute an averaged template.
    
    Args:
        samples: List of 1D numpy arrays of audio recordings.
        sr: Sample rate.
        n_mfcc: Number of MFCC coefficients.
        hop_length: FFT hop length.
        n_fft: FFT window size.
        trim_silence_flag: Whether to trim leading/trailing silence before extraction.
        
    Returns:
        Dictionary containing:
          - 'mfcc': Averaged MFCC matrix of shape (template_frames, n_mfcc)
          - 'energy_envelope': Averaged normalized RMS envelope of shape (template_frames,)
          - 'duration': Mean duration in seconds
          - 'sample_rate': Audio sample rate
          - 'n_mfcc': Number of coefficients
          - 'hop_length': Hop length
          - 'n_fft': FFT size
          - 'num_samples_enrolled': Count of samples enrolled
    """
    if not samples:
        raise ValueError("At least one audio sample is required to create a template.")

    processed_mfccs = []
    processed_envelopes = []
    durations = []

    for idx, sample in enumerate(samples):
        y = np.asarray(sample, dtype=np.float32).squeeze()
        if y.ndim > 1:
            y = y.mean(axis=-1)

        if trim_silence_flag:
            y, _ = trim_silence(y, top_db=25.0)

        duration = len(y) / sr
        durations.append(duration)

        mfcc = extract_mfcc(y, sr=sr, n_mfcc=n_mfcc, hop_length=hop_length, n_fft=n_fft)
        envelope = extract_energy_envelope(y, hop_length=hop_length, normalize=True)

        processed_mfccs.append(mfcc)
        processed_envelopes.append(envelope)

    # Determine representative frame count (median number of frames across samples)
    frame_counts = [len(m) for m in processed_mfccs if len(m) > 0]
    if not frame_counts:
        raise ValueError("All enrollment samples were empty or silent.")
    target_frames = int(round(float(np.median(frame_counts))))
    target_frames = max(target_frames, 5)

    # Resample each sample's features to target_frames and average
    aligned_mfccs = [resample_sequence_2d(m, target_frames) for m in processed_mfccs if len(m) > 0]
    aligned_envelopes = [resample_sequence_1d(e, target_frames) for e in processed_envelopes if len(e) > 0]

    averaged_mfcc = np.mean(aligned_mfccs, axis=0).astype(np.float32)
    averaged_envelope = np.mean(aligned_envelopes, axis=0).astype(np.float32)

    # Renormalize averaged envelope to [0, 1]
    env_max = np.max(averaged_envelope)
    if env_max > 1e-7:
        averaged_envelope = (averaged_envelope / env_max).astype(np.float32)

    return {
        "mfcc": averaged_mfcc,
        "energy_envelope": averaged_envelope,
        "duration": float(np.mean(durations)),
        "sample_rate": int(sr),
        "n_mfcc": int(n_mfcc),
        "hop_length": int(hop_length),
        "n_fft": int(n_fft),
        "num_samples_enrolled": int(len(samples)),
    }


def save_enrolled_template(
    template_dict: Dict[str, Union[np.ndarray, float, int]],
    filepath: Union[str, Path] = "enrolled_phrase.npy",
) -> Path:
    """
    Save template dictionary to a local .npy file.
    """
    target_path = Path(filepath).resolve()
    target_path.parent.mkdir(parents=True, exist_ok=True)
    np.save(str(target_path), template_dict, allow_pickle=True)
    return target_path


def load_enrolled_template(
    filepath: Union[str, Path] = "enrolled_phrase.npy",
) -> Dict[str, Union[np.ndarray, float, int]]:
    """
    Load template dictionary from a local .npy file.
    """
    target_path = Path(filepath).resolve()
    if not target_path.is_file():
        raise FileNotFoundError(f"Enrolled template not found at '{target_path}'. Run enroll.py first.")

    data = np.load(str(target_path), allow_pickle=True)
    if isinstance(data, np.ndarray) and data.dtype == object and data.shape == ():
        template_dict = data.item()
    elif isinstance(data, dict):
        template_dict = data
    else:
        raise ValueError(f"Invalid template format in '{target_path}'. Expected dict inside .npy.")

    required_keys = {"mfcc", "energy_envelope", "duration", "sample_rate"}
    missing = required_keys - set(template_dict.keys())
    if missing:
        raise KeyError(f"Template is missing required keys: {missing}")

    return template_dict