"""
Pattern Matching and Similarity Verification.

Combines Dynamic Time Warping (DTW) over MFCC feature vectors with
energy-envelope shape correlation for two-stage trigger verification.
"""

from dataclasses import dataclass
from typing import Dict, Optional, Tuple, Union
import numpy as np
from fastdtw import fastdtw
from scipy.spatial.distance import euclidean

from .features import resample_sequence_1d


# ==============================================================================
# CONFIGURABLE THRESHOLD CONSTANTS
# ==============================================================================
#
# DTW_DISTANCE_THRESHOLD:
#   Maximum allowed normalized Dynamic Time Warping distance between the sliding
#   audio window MFCCs and the enrolled template.
#
#   Tradeoffs:
#   - RAISING this threshold (e.g. 32.0 -> 40.0):
#       Increases sensitivity. More forgiving of tempo variations, accents, vocal
#       strain/pitch shifts under duress, or slight background noise.
#       TRADE-OFF: Increases false positives (may trigger on conversational words).
#   - LOWERING this threshold (e.g. 32.0 -> 24.0):
#       Increases specificity. Demands high phonetic alignment with enrollment.
#       TRADE-OFF: Increases false negatives (may miss trigger if user speaks faster,
#       whispers, or voice is altered by stress).
DTW_DISTANCE_THRESHOLD: float = 32.0


# ENERGY_SIMILARITY_THRESHOLD:
#   Minimum required correlation [0.0 to 1.0] between the window's
#   RMS energy envelope and the enrolled phrase envelope.
#
#   Tradeoffs:
#   - RAISING this threshold (e.g. 0.60 -> 0.75):
#       Requires the speech cadence, syllable stress, or exhale burst dynamics
#       to strictly mirror the enrolled rhythm. Rejects phonetically similar words
#       that have different syllable pacing.
#       TRADE-OFF: May reject the phrase if spoken with unusual pauses or breathlessness.
#   - LOWERING this threshold (e.g. 0.60 -> 0.40):
#       Tolerates variations in rhythm, cadence, and breath pacing.
#       TRADE-OFF: Relies more purely on MFCC spectral matching, increasing vulnerability
#       to unrelated speech patterns.
ENERGY_SIMILARITY_THRESHOLD: float = 0.60


@dataclass
class MatchResult:
    """Detailed outcome of a template match evaluation."""
    is_match: bool
    dtw_distance: float
    energy_similarity: float
    dtw_pass: bool
    energy_pass: bool
    dtw_threshold: float
    energy_threshold: float
    summary: str


def compute_dtw_distance(
    sample_mfcc: np.ndarray,
    template_mfcc: np.ndarray,
) -> Tuple[float, float, int]:
    """
    Calculate Dynamic Time Warping distance between sample MFCC sequence and template MFCC.
    
    Args:
        sample_mfcc: 2D array of shape (sample_frames, n_features).
        template_mfcc: 2D array of shape (template_frames, n_features).
        
    Returns:
        (normalized_distance, raw_distance, path_length)
        where normalized_distance = raw_distance / path_length.
    """
    if sample_mfcc is None or len(sample_mfcc) == 0:
        return float("inf"), float("inf"), 0
    if template_mfcc is None or len(template_mfcc) == 0:
        return float("inf"), float("inf"), 0

    # Ensure float64 2D arrays for numerical stability
    sample_mfcc = np.asarray(sample_mfcc, dtype=np.float64)
    template_mfcc = np.asarray(template_mfcc, dtype=np.float64)

    raw_dist, path = fastdtw(sample_mfcc, template_mfcc, dist=euclidean)
    path_len = max(len(path), 1)
    normalized_dist = float(raw_dist) / float(path_len)

    return normalized_dist, float(raw_dist), path_len


def compute_envelope_similarity(
    sample_envelope: np.ndarray,
    template_envelope: np.ndarray,
) -> float:
    """
    Compute cadence / rhythm similarity between sample and template energy envelopes.
    Uses sliding normalized cross-correlation to handle temporal offsets and duration
    differences between the candidate audio window and the enrolled template.
    
    Returns:
        Similarity score between 0.0 (uncorrelated/anti-correlated) and 1.0 (identical cadence).
    """
    if sample_envelope is None or len(sample_envelope) == 0:
        return 0.0
    if template_envelope is None or len(template_envelope) == 0:
        return 0.0

    s = np.asarray(sample_envelope, dtype=np.float64)
    t = np.asarray(template_envelope, dtype=np.float64)

    # Normalize peak amplitudes to 1.0
    max_s, max_t = np.max(s), np.max(t)
    if max_s > 1e-7:
        s = s / max_s
    if max_t > 1e-7:
        t = t / max_t

    std_t = np.std(t)
    if std_t < 1e-4:
        return 0.0  # Flat/silent template has no distinctive cadence

    best_corr = 0.0

    # Case 1: Sample is shorter than template -> resample sample to template length
    if len(s) < len(t):
        s_aligned = resample_sequence_1d(s, len(t))
        std_s = np.std(s_aligned)
        if std_s < 1e-4:
            return 0.0
        corr = np.corrcoef(s_aligned, t)[0, 1]
        return max(0.0, min(1.0, float(corr))) if not np.isnan(corr) else 0.0

    # Case 2: Overall resampled alignment
    s_resampled = resample_sequence_1d(s, len(t))
    if np.std(s_resampled) >= 1e-4:
        r_res = np.corrcoef(s_resampled, t)[0, 1]
        if not np.isnan(r_res):
            best_corr = max(best_corr, float(r_res))

    # Case 3: Sliding alignment across longer sample window
    win_len = len(t)
    for start in range(0, len(s) - win_len + 1):
        sub_s = s[start : start + win_len]
        std_sub = np.std(sub_s)
        if std_sub < 1e-4:
            continue
        corr = np.corrcoef(sub_s, t)[0, 1]
        if not np.isnan(corr) and corr > best_corr:
            best_corr = float(corr)

    return max(0.0, min(1.0, best_corr))


def evaluate_match(
    sample_mfcc: np.ndarray,
    sample_envelope: np.ndarray,
    template: Dict[str, Union[np.ndarray, float, int]],
    dtw_threshold: float = DTW_DISTANCE_THRESHOLD,
    energy_threshold: float = ENERGY_SIMILARITY_THRESHOLD,
) -> MatchResult:
    """
    Evaluate whether a candidate audio window matches the enrolled duress template.
    
    Both the DTW distance and energy envelope similarity must clear their respective thresholds.
    """
    template_mfcc = template["mfcc"]
    template_envelope = template["energy_envelope"]

    norm_dtw, raw_dtw, _ = compute_dtw_distance(sample_mfcc, template_mfcc)
    energy_sim = compute_envelope_similarity(sample_envelope, template_envelope)

    dtw_pass = norm_dtw <= dtw_threshold
    energy_pass = energy_sim >= energy_threshold
    is_match = dtw_pass and energy_pass

    summary = (
        f"DTW: {norm_dtw:.2f} (<= {dtw_threshold:.1f}: {dtw_pass}) | "
        f"Energy: {energy_sim:.2f} (>= {energy_threshold:.2f}: {energy_pass})"
    )

    return MatchResult(
        is_match=is_match,
        dtw_distance=norm_dtw,
        energy_similarity=energy_sim,
        dtw_pass=dtw_pass,
        energy_pass=energy_pass,
        dtw_threshold=dtw_threshold,
        energy_threshold=energy_threshold,
        summary=summary,
    )