"""
Live Detection Pipeline.

Continuously captures microphone audio in a background thread using sounddevice,
processes incoming audio in short overlapping sliding windows, maintains a rolling
30-second in-memory circular audio buffer, and silently evaluates DTW distance and
energy-envelope correlation against the enrolled duress template.

Runs completely SILENTLY during normal listening: no console output, no sounds,
and no audio persisted to disk unless a trigger fires.
"""

import queue
import threading
import time
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple, Union
import numpy as np
import sounddevice as sd

from .audio_buffer import CircularAudioBuffer
from .features import (
    DEFAULT_HOP_LENGTH,
    DEFAULT_N_FFT,
    DEFAULT_N_MFCC,
    DEFAULT_SAMPLE_RATE,
    extract_energy_envelope,
    extract_mfcc,
    load_enrolled_template,
)
from .matcher import (
    DTW_DISTANCE_THRESHOLD,
    ENERGY_SIMILARITY_THRESHOLD,
    MatchResult,
    evaluate_match,
)
from .trigger import trigger_action


# ==============================================================================
# PIPELINE CONFIGURATION CONSTANTS
# ==============================================================================
#
# WINDOW_SECONDS:
#   Duration of audio in seconds analyzed in each evaluation slice.
#   Typically 1.2 to 2.0s, matched to the typical duration of a trigger phrase.
DEFAULT_WINDOW_SECONDS: float = 1.5

# HOP_SECONDS:
#   Interval in seconds between successive evaluation windows.
#   A smaller hop (e.g. 0.25s - 0.5s) provides higher temporal resolution and lower
#   trigger latency, at the cost of slightly higher CPU utilization.
DEFAULT_HOP_SECONDS: float = 0.5

# BUFFER_CAPACITY_SECONDS:
#   Duration of the continuous in-memory circular buffer to preserve as evidence.
DEFAULT_BUFFER_CAPACITY_SECONDS: float = 30.0

# COOLDOWN_SECONDS:
#   Minimum refractory period between successive trigger events to prevent multiple
#   alerts firing for a single spoken utterance.
DEFAULT_COOLDOWN_SECONDS: float = 5.0


def process_audio_windows(
    audio: np.ndarray,
    sr: int,
    template: Dict[str, Union[np.ndarray, float, int]],
    window_seconds: float = DEFAULT_WINDOW_SECONDS,
    hop_seconds: float = DEFAULT_HOP_SECONDS,
    dtw_threshold: float = DTW_DISTANCE_THRESHOLD,
    energy_threshold: float = ENERGY_SIMILARITY_THRESHOLD,
) -> List[Tuple[float, MatchResult]]:
    """
    Process an audio array through sliding windows and evaluate each window.
    Used for offline testing and verification.
    
    Args:
        audio: 1D numpy array of audio samples.
        sr: Sample rate.
        template: Enrolled template dict.
        window_seconds: Window duration.
        hop_seconds: Hop step duration.
        dtw_threshold: Max allowed DTW distance.
        energy_threshold: Min required energy correlation.
        
    Returns:
        List of (window_start_time_sec, MatchResult).
    """
    audio = np.asarray(audio, dtype=np.float32).squeeze()
    if audio.ndim > 1:
        audio = audio.mean(axis=-1)

    window_samples = int(round(window_seconds * sr))
    hop_samples = int(round(hop_seconds * sr))
    total_samples = len(audio)

    results: List[Tuple[float, MatchResult]] = []

    if total_samples < window_samples:
        # Pad short audio with zeros to window_samples to allow evaluation
        padded = np.zeros(window_samples, dtype=np.float32)
        padded[:total_samples] = audio
        mfcc = extract_mfcc(padded, sr=sr)
        env = extract_energy_envelope(padded)
        res = evaluate_match(mfcc, env, template, dtw_threshold, energy_threshold)
        results.append((0.0, res))
        return results

    start_idx = 0
    while start_idx + window_samples <= total_samples:
        window = audio[start_idx : start_idx + window_samples]
        time_sec = start_idx / float(sr)

        mfcc = extract_mfcc(window, sr=sr)
        env = extract_energy_envelope(window)
        res = evaluate_match(mfcc, env, template, dtw_threshold, energy_threshold)
        results.append((time_sec, res))

        start_idx += hop_samples

    return results


class LiveDetectionPipeline:
    """
    Live duress trigger detection engine.
    
    Captures live audio via sounddevice in a background thread, maintains a 30s
    circular buffer in RAM, evaluates overlapping windows against an enrolled template,
    and executes trigger_action() upon a dual-score match.
    
    Operates in complete silence during normal listening.
    """

    def __init__(
        self,
        template: Optional[Dict[str, Union[np.ndarray, float, int]]] = None,
        template_path: Union[str, Path] = "enrolled_phrase.npy",
        window_seconds: float = DEFAULT_WINDOW_SECONDS,
        hop_seconds: float = DEFAULT_HOP_SECONDS,
        buffer_capacity_seconds: float = DEFAULT_BUFFER_CAPACITY_SECONDS,
        dtw_threshold: float = DTW_DISTANCE_THRESHOLD,
        energy_threshold: float = ENERGY_SIMILARITY_THRESHOLD,
        cooldown_seconds: float = DEFAULT_COOLDOWN_SECONDS,
        evidence_dir: Union[str, Path] = "evidence",
        log_path: Union[str, Path] = "alerts.log",
        device: Optional[Union[int, str]] = None,
        on_trigger_callback: Optional[Callable[[Path], None]] = None,
    ):
        if template is not None:
            self.template = template
        else:
            self.template = load_enrolled_template(template_path)

        self.sample_rate = int(self.template.get("sample_rate", DEFAULT_SAMPLE_RATE))
        self.window_seconds = float(window_seconds)
        self.hop_seconds = float(hop_seconds)
        self.window_samples = int(round(self.window_seconds * self.sample_rate))
        self.hop_samples = int(round(self.hop_seconds * self.sample_rate))

        self.dtw_threshold = float(dtw_threshold)
        self.energy_threshold = float(energy_threshold)
        self.cooldown_seconds = float(cooldown_seconds)
        self.evidence_dir = Path(evidence_dir)
        self.log_path = Path(log_path)
        self.device = device
        self.on_trigger_callback = on_trigger_callback

        # 30-second rolling in-memory buffer
        self.circular_buffer = CircularAudioBuffer(
            capacity_seconds=buffer_capacity_seconds,
            sample_rate=self.sample_rate,
            channels=1,
            dtype=np.float32,
        )

        # Threading and streaming state
        self._audio_queue: queue.Queue = queue.Queue(maxsize=100)
        self._window_accumulator: np.ndarray = np.zeros(0, dtype=np.float32)
        self._is_running = threading.Event()
        self._worker_thread: Optional[threading.Thread] = None
        self._stream: Optional[sd.InputStream] = None
        self._last_trigger_time: float = 0.0

    def _audio_callback(self, indata: np.ndarray, frames: int, time_info, status) -> None:
        """Called by sounddevice on the audio ingestion thread for each block."""
        if not self._is_running.is_set():
            return

        chunk = indata[:, 0].copy() if indata.ndim > 1 else indata.copy()

        # 1. Feed rolling 30-second evidence buffer
        self.circular_buffer.append(chunk)

        # 2. Queue for window detector worker
        try:
            self._audio_queue.put_nowait(chunk)
        except queue.Full:
            pass  # Drop frame if processing is severely backlogged rather than crashing

    def _worker_loop(self) -> None:
        """Background worker thread that slices audio into windows and runs matcher."""
        while self._is_running.is_set():
            try:
                chunk = self._audio_queue.get(timeout=0.1)
            except queue.Empty:
                continue

            self._window_accumulator = np.concatenate((self._window_accumulator, chunk))

            # Process all ready windows
            while len(self._window_accumulator) >= self.window_samples and self._is_running.is_set():
                window = self._window_accumulator[: self.window_samples]
                self._window_accumulator = self._window_accumulator[self.hop_samples :]

                # Extract features from candidate window
                window_mfcc = extract_mfcc(window, sr=self.sample_rate)
                window_env = extract_energy_envelope(window)

                # Evaluate against enrolled template
                result = evaluate_match(
                    sample_mfcc=window_mfcc,
                    sample_envelope=window_env,
                    template=self.template,
                    dtw_threshold=self.dtw_threshold,
                    energy_threshold=self.energy_threshold,
                )

                now = time.time()
                if result.is_match and (now - self._last_trigger_time >= self.cooldown_seconds):
                    self._last_trigger_time = now

                    saved_path = trigger_action(
                        buffer=self.circular_buffer,
                        evidence_dir=self.evidence_dir,
                        log_path=self.log_path,
                        metadata={
                            "dtw_dist": result.dtw_distance,
                            "energy_sim": result.energy_similarity,
                        },
                    )

                    if self.on_trigger_callback:
                        try:
                            self.on_trigger_callback(saved_path)
                        except Exception:
                            pass

    def start(self) -> None:
        """Start the live background audio capture and detection threads."""
        if self._is_running.is_set():
            return

        self._is_running.set()
        self._window_accumulator = np.zeros(0, dtype=np.float32)

        # Start analysis worker thread
        self._worker_thread = threading.Thread(target=self._worker_loop, daemon=True)
        self._worker_thread.start()

        # Start microphone input stream
        # Blocksize 1024 samples ~ 64ms latency
        self._stream = sd.InputStream(
            samplerate=self.sample_rate,
            channels=1,
            dtype="float32",
            blocksize=1024,
            device=self.device,
            callback=self._audio_callback,
        )
        self._stream.start()

    def stop(self) -> None:
        """Stop background capture and detection cleanly."""
        self._is_running.clear()

        if self._stream is not None:
            try:
                self._stream.stop()
                self._stream.close()
            except Exception:
                pass
            self._stream = None

        if self._worker_thread is not None and self._worker_thread.is_alive():
            self._worker_thread.join(timeout=1.0)
            self._worker_thread = None

    def run_forever(self) -> None:
        """
        Start detection and block until interrupted (e.g. via Ctrl+C).
        Maintains strict silence during operation.
        """
        self.start()
        try:
            while self._is_running.is_set():
                time.sleep(0.5)
        except KeyboardInterrupt:
            pass
        finally:
            self.stop()